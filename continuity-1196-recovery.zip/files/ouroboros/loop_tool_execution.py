"""LLM-loop tool execution: dispatch, timeouts, truncation, live logs."""

from __future__ import annotations

from ouroboros.model_wait import execution_deadline_scope, future_result, monotonic_now

import concurrent.futures
import contextlib
import contextvars
import json
import logging
import os
import pathlib
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Callable, Dict, Iterator, List, Optional

from ouroboros import budget_pause
from ouroboros.config import (
    NESTED_SETTLEMENT_MARGIN_SEC,
    get_finalization_grace_sec,
    load_settings,
)
from ouroboros.deadline_utils import deadline_remaining_sec
from ouroboros.observability import new_call_id, persist_call
from ouroboros.task_results import resolve_task_lineage
from ouroboros.tool_capabilities import (
    FOREGROUND_MUTATIVE_TOOLS,
    PARALLEL_SAFE_ENQUEUE_TOOLS,
    READ_ONLY_PARALLEL_TOOLS,
    REVIEWED_MUTATIVE_TOOLS,
    STATEFUL_BROWSER_TOOLS,
)
from ouroboros.tool_capabilities import (
    UNTRUNCATED_REPO_READ_PATHS as _UNTRUNCATED_REPO_READ_PATHS,
    UNTRUNCATED_REPO_READ_PREFIXES as _UNTRUNCATED_REPO_READ_PREFIXES,
)
from ouroboros.tool_capabilities import (
    UNTRUNCATED_TOOL_RESULTS as _UNTRUNCATED_TOOL_RESULTS,
)
from ouroboros.tool_capabilities import routing_action_for_tool
from ouroboros.tool_capabilities import (
    tool_result_limit as _tool_result_limit,
)
from ouroboros.tools.registry import ToolRegistry
from ouroboros.tools.tool_result import (
    TOOL_CODE_SPECS,
    LegacyTextResultAdapter,
    ToolResult,
)
from ouroboros.usage_accounting import UsageAccountingError
from ouroboros.utils import (
    append_jsonl,
    emit_cognitive_operation_event,
    emit_log_event,
    sanitize_tool_args_for_log,
    sanitize_tool_result_for_log,
    truncate_for_log,
    truncate_review_artifact,
    utc_now_iso,
)

log = logging.getLogger(__name__)

_PROCESS_RESULT_TOOLS = frozenset(
    {"run_command", "run_script", "start_service", "stop_service"}
)

def _emit_live_log(tools: ToolRegistry, payload: Dict[str, Any]) -> None:
    """Emit a live log through the registry context queue. Lineage (parent/root task
    ids) is merged in so a SUBAGENT's live log routes to its root project thread
    (C4.4) — only the root is bound, so without lineage the child's log stays in main."""
    tool_ctx = getattr(tools, "_ctx", None)
    event_queue = getattr(tool_ctx, "event_queue", None)
    enriched = dict(payload)
    meta = _tool_task_metadata(tools)
    for key in ("parent_task_id", "root_task_id"):
        if meta.get(key) and not enriched.get(key):
            enriched[key] = meta.get(key)
    # Tool execution is another physical wait surface.  Keep the idle rail
    # aware of it through the same typed operation seam as LLM/review calls;
    # a timeout/late notice deliberately does NOT close the lease because the
    # worker thread may still be running after the logical caller returned.
    operation_id = str(enriched.get("tool_call_id") or "")
    event_type = str(enriched.get("type") or "")
    if operation_id and event_type in {"tool_call_started", "tool_call_finished"}:
        emit_cognitive_operation_event(
            event_queue,
            task_id=str(enriched.get("task_id") or getattr(tool_ctx, "task_id", "") or ""),
            operation_id=operation_id,
            phase="started" if event_type == "tool_call_started" else "finished",
            kind="tool",
            task_attempt=getattr(tool_ctx, "task_attempt", None),
            execution_id=str(enriched.get("execution_id") or ""),
            round_id=str(enriched.get("round_id") or ""),
            tool=str(enriched.get("tool") or ""),
        )
    emit_log_event(
        event_queue,
        {"ts": utc_now_iso(), **enriched},
        log_label="tool live",
    )


def _attach_late_tool_settlement(
    tools: ToolRegistry,
    future: Any,
    *,
    task_id: str,
    tool_call_id: str,
    correlation: Dict[str, Any],
    on_settled: Optional[Callable[[], None]] = None,
) -> None:
    """Close the cognitive lease when a timed-out worker finally settles."""
    tool_ctx = getattr(tools, "_ctx", None)
    event_queue = getattr(tool_ctx, "event_queue", None)
    # Claim the quiescence row BEFORE attaching: a budget pause may not release
    # the native worker while this callback is still producing effects, and
    # ``future.done()`` is not callback-complete (#1196).
    release_quiescence = budget_pause.hold_tool_settlement(tool_ctx, tool_call_id)

    def _settled(_future: Any) -> None:
        try:
            if on_settled is not None:
                try:
                    on_settled()
                except Exception:
                    log.debug("Late tool cleanup failed", exc_info=True)
            emit_cognitive_operation_event(
                event_queue,
                task_id=task_id,
                operation_id=tool_call_id,
                phase="finished",
                kind="tool",
                task_attempt=getattr(tool_ctx, "task_attempt", None),
                execution_id=str(correlation.get("execution_id") or ""),
                round_id=str(correlation.get("round_id") or ""),
                tool=str(correlation.get("tool") or ""),
            )
        finally:
            release_quiescence()

    try:
        future.add_done_callback(_settled)
    except Exception:
        log.debug("Failed to attach late tool settlement callback", exc_info=True)
        release_quiescence()


def _tool_correlation(tools: ToolRegistry) -> Dict[str, Any]:
    ctx = getattr(tools, "_ctx", None)
    meta = getattr(ctx, "_current_llm_call_meta", {}) if ctx is not None else {}
    return dict(meta) if isinstance(meta, dict) else {}


def _tool_task_metadata(tools: ToolRegistry) -> Dict[str, Any]:
    ctx = getattr(tools, "_ctx", None)
    meta = getattr(ctx, "task_metadata", {}) if ctx is not None else {}
    data = dict(meta) if isinstance(meta, dict) else {}
    for key in ("parent_task_id", "root_task_id", "delegation_role"):
        if data.get(key):
            continue
        value = getattr(ctx, key, "") if ctx is not None else ""
        if value:
            data[key] = value
    if ctx is not None and getattr(ctx, "task_depth", None) is not None:
        data.setdefault("task_depth", getattr(ctx, "task_depth"))
    if ctx is not None and getattr(ctx, "budget_drive_root", ""):
        data.setdefault("budget_drive_root", getattr(ctx, "budget_drive_root"))
    return data


def _append_tool_log(tools: ToolRegistry, drive_logs: pathlib.Path, payload: Dict[str, Any]) -> None:
    meta = _tool_task_metadata(tools)
    if task_id := str(payload.get("task_id") or "").strip():
        # ONE lineage resolver (a direct root is its own root), so every task row
        # carries root_task_id/delegation_role for the task log stream readers.
        lineage = resolve_task_lineage(task_id, metadata=meta)
        payload["root_task_id"] = lineage["root_task_id"]
        if role := lineage["delegation_role"] or ("root" if lineage["is_root_task"] else ""):
            payload["delegation_role"] = role
    for key in ("parent_task_id", "task_depth"):
        if meta.get(key) not in (None, ""):
            payload[key] = meta.get(key)
    append_jsonl(drive_logs / "tools.jsonl", payload)
    root = str(meta.get("budget_drive_root") or "").strip()
    if not root:
        return
    candidate = pathlib.Path(root).resolve(strict=False) / "logs" / "tools.jsonl"
    try:
        if candidate.resolve(strict=False) == (pathlib.Path(drive_logs) / "tools.jsonl").resolve(strict=False):
            return
    except Exception:
        pass
    append_jsonl(candidate, payload)


def _with_correlation(payload: Dict[str, Any], correlation: Dict[str, Any], *, tool_call_id: str = "") -> Dict[str, Any]:
    out = dict(payload)
    for key in ("execution_id", "round_id", "llm_call_id"):
        if correlation.get(key):
            out[key] = correlation.get(key)
    if tool_call_id:
        out["tool_call_id"] = tool_call_id
    return out


_PER_CALL_TIMEOUT_TOOLS = ("run_command", "run_script")
# TYPED process facts (exit_code, POSIX signal name, duration_ms, timed_out,
# killed_by_host, pre_exec_failure — plus resolved_runtime when the interpreter
# resolver substituted the executable) reach this loop through the thread-local
# channel in ouroboros.tools.process_facts. The channel is PUBLISHER-scoped, not
# name-scoped: any handler that measures a child of its own call publishes there
# (run_command/run_script, skill_exec, skill_preflight validators,
# verify_and_record checks, out-of-process extension children), so the loop
# clears the slot before every dispatch and merges whatever the call itself
# published. Typed facts take PRECEDENCE over the producer-meta copy from the
# ToolResult; a record with no typed publication carries no process facts at all
# (D02: prose is never harvested into typed fields).
# Structural ordering margin: the outer cap sits this far above the requested
# per-call timeout so the handler's own (cleanly-messaged) subprocess timeout
# fires first, before the outer thread-kill. Not a wait duration — a race margin.
_PER_CALL_TIMEOUT_OUTER_MARGIN_SEC = NESTED_SETTLEMENT_MARGIN_SEC


def _tc_args(tc: Dict[str, Any]) -> Dict[str, Any]:
    """Best-effort parse of a tool call's JSON arguments (for timeout resolution)."""
    try:
        raw = (tc.get("function") or {}).get("arguments")
        if isinstance(raw, dict):
            return raw
        if isinstance(raw, str) and raw.strip():
            parsed = json.loads(raw)
            return parsed if isinstance(parsed, dict) else {}
    except (ValueError, TypeError, AttributeError):
        pass
    return {}


def _get_tool_timeout(
    tools: ToolRegistry, tool_name: str, tool_args: Optional[Dict[str, Any]] = None
) -> int:
    """Return max(settings/env timeout, per-tool minimum).

    For ``run_command``/``run_script`` a per-call ``timeout_sec`` (or its
    ``timeout`` alias) raises this OUTER tool-execution cap so the handler's own
    deadline-clamped subprocess timeout fires first — otherwise a legitimately
    long ``run_command(timeout_sec=900)`` would be cut off at the static 360s
    entry cap before the inner timeout matters. A +30s margin lets the inner
    (cleanly-messaged) timeout win over the outer thread-kill.
    """
    settings_val = 0
    try:
        settings_val = int(load_settings().get("OUROBOROS_TOOL_TIMEOUT_SEC") or 0)
    except Exception:
        pass
    if settings_val <= 0:
        env_val = os.environ.get("OUROBOROS_TOOL_TIMEOUT_SEC")
        if env_val:
            try:
                parsed = int(env_val)
                if parsed > 0:
                    settings_val = parsed
            except ValueError:
                pass
    per_tool = tools.get_timeout(tool_name)
    base = max(settings_val, per_tool) if settings_val > 0 else per_tool
    if tool_name in {"analyze_screenshot", "vlm_query"}:
        from ouroboros.tools.vision import _vision_tool_timeout

        base = max(base, _vision_tool_timeout(tools._ctx, tool_args or {}))
    if tool_name in _PER_CALL_TIMEOUT_TOOLS and isinstance(tool_args, dict):
        raw = tool_args.get("timeout_sec", tool_args.get("timeout"))
        try:
            override = int(raw) if raw is not None else 0
        except (TypeError, ValueError):
            override = 0
        if override > 0:
            from ouroboros.config import get_per_call_timeout_ceiling_sec

            return min(max(base, override), get_per_call_timeout_ceiling_sec()) + _PER_CALL_TIMEOUT_OUTER_MARGIN_SEC
    return _deadline_clamped_timeout(tools, tool_name, base)


# Network/long-wait tools whose OUTER timeout is clamped to the remaining task
# deadline (v6.54.3, 1.4A): one in-flight web_search with a 540s ceiling could
# otherwise swallow the whole remaining budget — finalize_now drains only at
# round boundaries, so the task slid past its deadline mid-tool (TB2.1
# gpt2-codegolf post-mortem). Local media/process tools stay unclamped: the
# per-call/run_command machinery and the deadline milestones own those.
_DEADLINE_CLAMPED_TOOLS = frozenset({
    "web_search", "browse_page", "browser_action", "youtube_transcript",
    "wait_task", "wait_tasks", "plan_task", "task_acceptance_review",
    "analyze_screenshot", "vlm_query",
})


def _deadline_clamped_timeout(tools: ToolRegistry, tool_name: str, base_timeout: int) -> int:
    """min(tool timeout, remaining − finalization reserve) for network/long tools.

    Without ``deadline_at`` (remaining reads 0.0) the behavior is byte-identical.
    An already-elapsed deadline is also left unclamped — the loop's forced
    finalization owns that path. The clamp never floors PAST the reserve: inside
    or near the finalization window the tool gets a near-immediate (1s) timeout —
    a fast, cleanly-messaged failure — rather than a grace-period-eating floor
    (review round 1: a 30s floor let one web call consume the reserve the clamp
    exists to protect)."""
    if tool_name not in _DEADLINE_CLAMPED_TOOLS:
        return base_timeout
    try:
        remaining = deadline_remaining_sec(getattr(tools, "_ctx", None))
    except Exception:
        return base_timeout
    if remaining <= 0:
        return base_timeout
    # v6.55.0: the plain finalization GRACE emit-window (task_pacing SSOT) — the
    # tool must return before the deadline leaves no time to emit a final answer.
    # NOT the pct reserve (an acceptance-review gate concept): clamping a tool out
    # of the last pct-of-total would strand long tasks with idle time.
    try:
        from ouroboros.task_pacing import effective_finalization_reserve_sec

        reserve = effective_finalization_reserve_sec(getattr(tools, "_ctx", None))
    except Exception:
        reserve = float(get_finalization_grace_sec())
    window = remaining - reserve
    if window >= base_timeout:
        return base_timeout
    return int(max(1.0, min(float(base_timeout), window)))


def _path_is_cognitive_artifact(tool_name: str, tool_args: Optional[Dict[str, Any]]) -> bool:
    """Return whether a read target must stay whole."""
    if not tool_args:
        return False

    raw_path = str(tool_args.get("path") or "").strip()
    if not raw_path:
        return False

    normalized = raw_path.replace("\\", "/").lstrip("./")

    if tool_name == "read_file" and str((tool_args or {}).get("root") or "active_workspace") == "runtime_data":
        return normalized.startswith("memory/") and "/_backup/" not in normalized

    if tool_name == "read_file":
        return (normalized.startswith(_UNTRUNCATED_REPO_READ_PREFIXES)
                or normalized in _UNTRUNCATED_REPO_READ_PATHS)

    return False


def _should_skip_tool_result_truncation(
    tool_name: str,
    tool_args: Optional[Dict[str, Any]] = None,
) -> bool:
    """Canonical/cognitive reads must remain whole."""
    return tool_name in _UNTRUNCATED_TOOL_RESULTS or _path_is_cognitive_artifact(tool_name, tool_args)


def _truncate_tool_result(
    result: Any,
    tool_name: str = "",
    tool_args: Optional[Dict[str, Any]] = None,
    source_ref: Optional[Dict[str, Any]] = None,
) -> str:
    """Cap tool result unless it is an untruncated artifact."""
    limit = _tool_result_limit(tool_name)
    s = str(result)
    if _should_skip_tool_result_truncation(tool_name, tool_args):
        return s
    if len(s) <= limit:
        return s
    marker = f"\n... (truncated from {len(s)} chars, limit={limit})"
    if isinstance(source_ref, dict) and source_ref:
        recover = (
            "Read the exact source above, or page this tool (offset/limit) for the omitted range."
            if tool_name in _PAGEABLE_TOOL_RESULTS
            else "Do not rerun this tool to recover omitted output. Read the exact source above."
        )
        marker += (
            "\nFULL_RESULT_SOURCE_JSON="
            + json.dumps(source_ref, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            + "\n" + recover
        )
    else:
        marker += (
            "\nFULL_RESULT_SOURCE_UNAVAILABLE=true"
            "\nDo not treat this partial result as complete; exact source persistence failed."
        )
    return s[:limit] + marker


# Tools whose own affordance IS paging. This selects the marker WORDING only: it
# no longer exempts the result from source persistence, because the acceptance
# decider has no way to page a tool the agent ran — it can only read the exact
# bytes the host persisted.
_PAGEABLE_TOOL_RESULTS = frozenset({
    "read_file", "chat_history", "journal_read", "tree_read", "recent_tasks", "query_code",
})


def _persist_truncated_tool_source(
    ctx: Any,
    tool_name: str,
    tool_call_id: str,
    result: Any,
    tool_args: Optional[Dict[str, Any]] = None,
    *,
    force: bool = False,
) -> Dict[str, Any]:
    """Write a generic over-limit result to this actor's existing artifact root."""

    text = str(result)
    if not force and (
        _should_skip_tool_result_truncation(tool_name, tool_args)
        or len(text) <= _tool_result_limit(tool_name)
    ):
        return {}
    try:
        from ouroboros.artifacts import store_actor_source_bytes, task_id_for_artifacts

        return store_actor_source_bytes(
            pathlib.Path(ctx.drive_root),
            task_id_for_artifacts(ctx),
            category="tool_results",
            source_id=str(tool_call_id or new_call_id("tool_result")),
            data=text.encode("utf-8"),
            extension="txt",
        )
    except Exception:
        log.warning("Failed to persist actor-readable tool result source", exc_info=True)
        return {}




def _typed_execution_failure(tool_ok: bool, tool_result: ToolResult | None) -> bool:
    """Whether the call failed, read from the published code instead of its text."""
    if not tool_ok:
        return True
    if not isinstance(tool_result, ToolResult):
        return False
    return TOOL_CODE_SPECS[tool_result.code].status != "ok"


def _is_tool_execution_failure(
    tool_ok: bool,
    result: Any,
    tool_result: ToolResult | None = None,
    *,
    fn_name: str = "",
) -> bool:
    """Compatibility wrapper for text-only callers (old name and signature).

    The loop itself holds the dispatcher's published ``ToolResult`` and reads
    ``_typed_execution_failure`` directly (ABI-6(b): no re-adaptive branch on
    the hot path); a caller holding only text gets the ONE adapter's reading,
    so it sees the same classification the loop records."""
    if not isinstance(tool_result, ToolResult):
        tool_result = LegacyTextResultAdapter.from_text(fn_name, str(result or ""))
    return _typed_execution_failure(tool_ok, tool_result)


def _extract_result_metadata(
    fn_name: str,
    result: Any,
    is_error: bool,
    tool_result: ToolResult | None = None,
) -> Dict[str, Any]:
    """Compatibility wrapper for text-only callers (old name and signature)."""
    if not isinstance(tool_result, ToolResult):
        tool_result = LegacyTextResultAdapter.from_text(fn_name, str(result or ""))
    return _typed_result_metadata(fn_name, result, is_error, tool_result)


def _typed_result_metadata(
    fn_name: str,
    result: Any,
    is_error: bool,
    tool_result: ToolResult | None = None,
) -> Dict[str, Any]:
    """Outcome facts for summaries and reflections, taken from the typed result.

    The status is the code's ``outcome_bucket``, which IS the trace vocabulary the
    outcome classifier, the reflection scan and the web client already read, so the
    cutover replaces the PRODUCER of the field, not its consumers.

    The rules below are deliberately NOT text classification and stay here: the
    untruncated artifact-registration fallback, the plan-review metadata, the
    process facts with the ``run_command`` exit-0 override, and the
    skill-publish projection — all keyed on the tool name and on trusted meta.
    """
    text = str(result or "")
    if isinstance(tool_result, ToolResult):
        status = TOOL_CODE_SPECS[tool_result.code].outcome_bucket
    else:
        status = "error" if is_error else "ok"

    meta: Dict[str, Any] = {"status": status}
    # Legacy non-process deliverable fallback reads the FULL result before trace
    # truncation. Process producers must supply the typed fact below.
    if (
        fn_name not in _PROCESS_RESULT_TOOLS
        and not is_error
        and "ARTIFACT_OUTPUTS" in text
    ):
        meta["artifact_registered"] = True
    if fn_name == "plan_task" and not is_error and isinstance(tool_result, ToolResult):
        plan_outcome = tool_result.meta.get("plan_review_outcome")
        plan_closed = tool_result.meta.get("plan_review_closed")
        if (
            plan_outcome in {"GREEN", "REVIEW_REQUIRED", "REVISE_PLAN", "DEGRADED"}
            and type(plan_closed) is bool
            and not (plan_outcome == "GREEN" and not plan_closed)
            and not (plan_outcome in {"REVISE_PLAN", "DEGRADED"} and plan_closed)
        ):
            meta["plan_review_outcome"] = plan_outcome
            meta["plan_review_closed"] = plan_closed
    if isinstance(tool_result, ToolResult) and tool_result.meta.get("post_commit_tests") == "failed":
        # A preserved commit whose post-commit tests failed is a SUCCESS that
        # still holds a failure the reflection triggers must see. The producer
        # states it; nothing here reads the result body for the word.
        meta["post_commit_tests"] = "failed"
    if fn_name in _PROCESS_RESULT_TOOLS and isinstance(tool_result, ToolResult):
        exit_code = tool_result.meta.get("exit_code")
        if isinstance(exit_code, int) and not isinstance(exit_code, bool):
            meta["exit_code"] = exit_code
        signal_name = tool_result.meta.get("signal")
        if isinstance(signal_name, str) and signal_name:
            meta["signal"] = signal_name
        if tool_result.meta.get("artifact_registered") is True:
            meta["artifact_registered"] = True
    if (
        meta["status"] == "ok"
        and isinstance(tool_result, ToolResult)
        and tool_result.meta.get("shell_regex_auto_corrected") is True
    ):
        # The autocorrection is a producer FACT carried in meta, not a text prefix.
        # A shell producer that also has a more specific code (no-match, exit error,
        # undeclared outputs) keeps that code; only an otherwise-plain success is
        # relabelled, which is what the retired text scan did for every shape.
        meta["status"] = "ok_autocorrected"
    if fn_name == "run_command" and not is_error and meta.get("exit_code") == 0:
        if meta["status"] == "ok_autocorrected":
            meta["status"] = "ok_autocorrected"
        else:
            meta["status"] = "ok"
    if fn_name == "submit_skill_to_hub":
        from ouroboros.skill_publish_result import extract_skill_publish_result_metadata

        meta.update(extract_skill_publish_result_metadata(result))
    return meta


def _process_fact_fields(result_meta: Dict[str, Any]) -> Dict[str, Any]:
    """The typed process facts this call published, for the record consumers.

    One projection for the UI live-log card, the tools.jsonl row and the trace
    manifest, so every surface names the same members from the same merge —
    a member absent from ``result_meta`` stays absent here rather than being
    rendered as a null fact.
    """
    from ouroboros.tools.process_facts import PROCESS_FACT_KEYS

    return {key: result_meta[key] for key in PROCESS_FACT_KEYS if key in result_meta}


def _tool_result_fields(result: ToolResult) -> Dict[str, Any]:
    """Return the JSON-safe typed projection without shadowing legacy fields."""
    return {
        "tool_result_status": result.status,
        "tool_result_code": result.code,
        "tool_result_meta": dict(result.meta),
    }

def _execute_browser_tool_bound(
    tools: ToolRegistry,
    tc: Dict[str, Any],
    drive_logs: pathlib.Path,
    task_id: str,
    generation: Any,
) -> Dict[str, Any]:
    """The stateful (browser) submit wrapper: the call is BOUND to the browser
    generation the main thread saw at submit time. A call that only STARTS
    after its generation was retired (its own timeout fired before the worker
    reached the tool body) must not touch the replacement — its result goes to
    the settlement void anyway, so it refuses instead of executing."""
    tool_ctx = getattr(tools, "_ctx", None)
    current = getattr(tool_ctx, "browser_state", None) if tool_ctx is not None else None
    if generation is not None and current is not None and current is not generation:
        return {
            "tool_call_id": tc.get("id"),
            "fn_name": str(tc.get("function", {}).get("name") or ""),
            "result": ("⚠️ BROWSER_SESSION_RETIRED: this call timed out before it "
                       "started and its browser generation was retired; nothing ran."),
            "is_error": True,
            "args_for_log": {},
            "is_code_tool": False,
        }
    if tool_ctx is not None and generation is not None:
        # Pin the expectation for the tool body: _ensure_browser re-checks it
        # at the exact moment it captures the generation, which closes the
        # check-then-run window (safety checks between here and the handler
        # can be long). _ensure_browser's own legitimate replacements update
        # the pin, so a mid-call error after such a replacement is never
        # mistaken for a timeout retirement.
        setattr(tool_ctx, "_active_browser_generation", generation)
    return _execute_single_tool(tools, tc, drive_logs, task_id)


def _execute_single_tool(
    tools: ToolRegistry,
    tc: Dict[str, Any],
    drive_logs: pathlib.Path,
    task_id: str = "",
) -> Dict[str, Any]:
    """
    Execute a single tool call and return all needed info.

    Returns dict with: tool_call_id, fn_name, result, is_error, args_for_log, is_code_tool
    """
    requested_fn_name = tc["function"]["name"]
    fn_name = str(requested_fn_name or "").strip()
    tool_call_id = tc["id"]
    is_code_tool = fn_name in tools.CODE_TOOLS
    correlation = _tool_correlation(tools)

    try:
        args = json.loads(tc["function"]["arguments"] or "{}")
    except (json.JSONDecodeError, ValueError) as e:
        result = f"⚠️ TOOL_ARG_ERROR: Could not parse arguments for '{requested_fn_name}': {e}"
        tool_result = ToolResult(status="error", code="TOOL_ARG_ERROR", text=result)
        result_meta = {
            **_typed_result_metadata(fn_name, result, True, tool_result),
            **_tool_result_fields(tool_result),
        }
        trace_ref = {}
        try:
            trace_ref = persist_call(
                pathlib.Path(drive_logs).parent,
                task_id=task_id,
                call_id=new_call_id("tool_arg_error"),
                call_type="tool_call",
                payload={
                    "tool": fn_name,
                    "tool_call_id": tool_call_id,
                    "parent_call_id": correlation.get("llm_call_id"),
                    "execution_id": correlation.get("execution_id"),
                    "round_id": correlation.get("round_id"),
                    "raw_arguments": tc.get("function", {}).get("arguments"),
                    "result": result,
                    "result_meta": result_meta,
                },
                manifest={
                    "execution_id": correlation.get("execution_id"),
                    "round_id": correlation.get("round_id"),
                    "parent_call_id": correlation.get("llm_call_id"),
                    "tool_call_id": tool_call_id,
                    "tool": fn_name,
                    "status": "arg_error",
                    "tool_code": tool_result.code,
                    "error_preview": truncate_for_log(sanitize_tool_result_for_log(result), 600),
                },
            )
        except Exception:
            log.debug("Failed to persist tool arg-error observability payload", exc_info=True)
        return {
            "tool_call_id": tool_call_id,
            "fn_name": fn_name,
            "result": result,
            "is_error": True,
            "tool_args": {},
            "args_for_log": {},
            "is_code_tool": is_code_tool,
            "trace_ref": trace_ref, "round_id": correlation.get("round_id"),
            "result_meta": result_meta,
            "tool_result": tool_result,
        }

    args_for_log = sanitize_tool_args_for_log(fn_name, args if isinstance(args, dict) else {})

    # Drop any stale thread-local facts before dispatch so a path that runs NO
    # process of its own (arg errors, blocks, a plain read) can never inherit a
    # previous call's measurements.
    from ouroboros.tools.process_facts import consume_last_process_facts

    consume_last_process_facts()

    tool_ok = True
    try:
        tool_result = tools.execute_result(fn_name, args)
        result = tool_result.text
    except UsageAccountingError:
        raise
    except Exception as e:
        tool_ok = False
        safe_error = sanitize_tool_result_for_log(f"{type(e).__name__}: {e}")
        result = f"⚠️ TOOL_ERROR ({fn_name}): {safe_error}"
        tool_result = ToolResult(status="error", code="EXECUTOR_ERROR", text=result)
        append_jsonl(drive_logs / "events.jsonl", _with_correlation({
            "ts": utc_now_iso(), "type": "tool_error", "task_id": task_id,
            "tool": fn_name, "args": args_for_log, "error": safe_error,
        }, correlation, tool_call_id=tool_call_id))

    # `status`/`is_error` are READ from the published code, never re-derived from
    # the text; process exit, signal and artifact-registration facts come from
    # typed meta, so producer-controlled stdout can forge none of them (ABI-6(b):
    # the loop holds the dispatcher's typed result and reads it directly).
    is_error = _typed_execution_failure(tool_ok, tool_result)
    result_meta = {
        **_typed_result_metadata(fn_name, result, is_error, tool_result),
        **_tool_result_fields(tool_result),
    }
    # R5 (node-runtime sprint): merge the handler's TYPED process facts into
    # the call's result_meta. When a typed publication exists it owns the WHOLE
    # fact family — including the ABSENCE of a member (a typed publication
    # without ``signal`` means the child was not signal-killed). It carries the
    # members the ToolResult meta does not (duration_ms, resolved_runtime,
    # timed_out, killed_by_host, pre_exec_failure) and takes precedence over the
    # producer-meta copy of the shared ones; records with no typed publication
    # keep the ToolResult-meta facts from _typed_result_metadata unchanged.
    from ouroboros.tools.process_facts import PROCESS_FACT_KEYS

    process_facts = consume_last_process_facts()
    if process_facts:
        for stale_key in PROCESS_FACT_KEYS:
            result_meta.pop(stale_key, None)
        result_meta.update(process_facts)

    trace_ref = {}
    try:
        trace_ref = persist_call(
            pathlib.Path(drive_logs).parent,
            task_id=task_id,
            call_id=new_call_id(f"tool_{fn_name}"),
            call_type="tool_call",
            payload={
                "tool": fn_name,
                "tool_call_id": tool_call_id,
                "parent_call_id": correlation.get("llm_call_id"),
                "execution_id": correlation.get("execution_id"),
                "round_id": correlation.get("round_id"),
                "args": args,
                "result": result,
                **({"producer_result": tool_result.producer_text,
                    "host_annotations": list(tool_result.host_annotations)}
                   if tool_result.producer_text is not None else {}),
                "tool_ok": tool_ok,
                "semantic_ok": not is_error,
                "result_meta": result_meta,
            },
            manifest={
                "execution_id": correlation.get("execution_id"),
                "round_id": correlation.get("round_id"),
                "parent_call_id": correlation.get("llm_call_id"),
                "tool_call_id": tool_call_id,
                "tool": fn_name,
                "status": str(result_meta.get("status") or ("ok" if tool_ok else "exception")),
                "semantic_ok": not is_error,
                "tool_code": tool_result.code,
                **({"error_preview": truncate_for_log(sanitize_tool_result_for_log(result), 600)} if is_error else {}),
            },
        )
    except Exception:
        log.debug("Failed to persist tool observability payload", exc_info=True)

    _append_tool_log(tools, drive_logs, _with_correlation({
        "ts": utc_now_iso(), "type": "tool_call", "tool": fn_name, "task_id": task_id,
        "args": args_for_log,
        "result_preview": sanitize_tool_result_for_log(truncate_for_log(result, 2000)),
        "is_error": is_error,
        "status": result_meta.get("status"),
        # The typed process facts of THIS call ride the direct tools.jsonl row
        # too: the row is the surface an operator greps, and a killed or
        # never-started child must be readable there without the trace.
        **_process_fact_fields(result_meta),
        # Typed producer meta rides the DIRECT record too (bounded by the
        # ToolResult contract: <=32 keys, <=8KB, JSON-safe) so durable
        # provenance facts — the ABI-9 extension_generation digest included —
        # survive even when persist_call fails.
        "tool_result_meta": result_meta.get("tool_result_meta") or {},
        "args_ref": (trace_ref.get("manifest_ref") or {}).get("path") if trace_ref else None,
        "result_ref": trace_ref.get("manifest_ref") if trace_ref else None,
    }, correlation, tool_call_id=tool_call_id))

    return {
        "tool_call_id": tool_call_id,
        "fn_name": fn_name,
        "result": result,
        "is_error": is_error,
        "tool_args": args if isinstance(args, dict) else {},
        "args_for_log": args_for_log,
        "is_code_tool": is_code_tool,
        "trace_ref": trace_ref, "round_id": correlation.get("round_id"),
        "result_meta": result_meta,
        "tool_result": tool_result,
    }


class StatefulToolExecutor:
    """Thread-sticky executor for Playwright/greenlet stateful tools."""
    def __init__(self):
        self._executor: Optional[ThreadPoolExecutor] = None

    def submit(self, fn, *args, **kwargs):
        """Submit work to the sticky thread."""
        if self._executor is None:
            self._executor = ThreadPoolExecutor(max_workers=1, thread_name_prefix="stateful_tool")
        context = contextvars.copy_context()
        return self._executor.submit(context.run, fn, *args, **kwargs)

    def reset(self):
        """Reset the sticky thread after timeout/error."""
        if self._executor is not None:
            self._executor.shutdown(wait=False, cancel_futures=True)
            self._executor = None

    def retire(self):
        """Detach from the sticky thread WITHOUT cancelling queued work.

        The timeout path queues the browser-generation cleanup BEHIND the
        hung call on this same thread; reset()'s cancel_futures would cancel
        exactly that cleanup and leak the browser."""
        if self._executor is not None:
            self._executor.shutdown(wait=False, cancel_futures=False)
            self._executor = None

    def shutdown(self, wait=True, cancel_futures=False):
        """Shutdown the sticky executor."""
        if self._executor is not None:
            self._executor.shutdown(wait=wait, cancel_futures=cancel_futures)
            self._executor = None


def tool_timeout_text(fn_name: str, timeout_sec: float, reset_msg: str = "") -> str:
    """The ONE sentence a model reads when its own tool call was abandoned.

    Shared with the native reviewer episode, whose inspection calls run under
    this same timeout policy: two spellings of "your tool did not come back"
    would be two contracts for one host fact.
    """
    return (
        f"⚠️ TOOL_TIMEOUT ({fn_name}): exceeded {timeout_sec}s limit. "
        f"The tool is still running in background but control is returned to you. "
        f"{reset_msg}Try a different approach or inform the user{' about the issue' if not reset_msg else ''}."
    )


@contextlib.contextmanager
def abandoned_on_timeout(timeout_sec: float, *, bounded: bool = True) -> Iterator[Callable[..., Any]]:
    """Own the private worker of ONE call so a timed-out call can be ABANDONED.

    The late-settlement half of tool execution, without its task-log rows, so
    the native reviewer episode bounds its inspection calls on the same
    mechanics the loop uses: the worker inherits the caller's execution
    deadline through a copied context (its inner waits share the bound), the
    caller waits with ``future_result`` (a quota pause does not spend the
    budget), and the executor is retired WITHOUT joining — a caller that timed
    out walks away, and the value the worker settles on later is evidence of
    nothing. ``bounded=False`` leaves the context unscoped for a terminal wait
    that must not be cut at all.
    """
    executor = ThreadPoolExecutor(max_workers=1)
    try:
        with (execution_deadline_scope(monotonic_now() + timeout_sec) if bounded
              else contextlib.nullcontext()):
            context = contextvars.copy_context()
        yield lambda fn, *args: executor.submit(context.run, fn, *args)
    finally:
        executor.shutdown(wait=False, cancel_futures=True)


def _make_timeout_result(
    fn_name: str,
    tool_call_id: str,
    is_code_tool: bool,
    tc: Dict[str, Any],
    drive_logs: pathlib.Path,
    timeout_sec: int,
    task_id: str = "",
    reset_msg: str = "",
    correlation: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Create and log a timeout result."""
    args_for_log = {}
    raw_args: Dict[str, Any] = {}
    try:
        args = json.loads(tc["function"]["arguments"] or "{}")
        raw_args = args if isinstance(args, dict) else {}
        args_for_log = sanitize_tool_args_for_log(fn_name, raw_args)
    except Exception:
        pass

    result = tool_timeout_text(fn_name, timeout_sec, reset_msg)
    tool_result = ToolResult(
        status="timeout",
        code="TOOL_TIMEOUT",
        text=result,
        meta={"timeout_sec": timeout_sec},
    )
    result_meta = {
        **_typed_result_metadata(fn_name, result, True, tool_result),
        **_tool_result_fields(tool_result),
    }
    trace_ref = {}
    corr = dict(correlation or {})
    try:
        trace_ref = persist_call(
            pathlib.Path(drive_logs).parent,
            task_id=task_id,
            call_id=new_call_id(f"tool_timeout_{fn_name}"),
            call_type="tool_timeout",
            payload={
                "tool": fn_name,
                "tool_call_id": tool_call_id,
                "parent_call_id": corr.get("llm_call_id"),
                "execution_id": corr.get("execution_id"),
                "round_id": corr.get("round_id"),
                "timeout_sec": timeout_sec,
                "args": raw_args,
                "args_redacted_preview": args_for_log,
                "result": result,
                "result_meta": result_meta,
            },
            manifest={
                "execution_id": corr.get("execution_id"),
                "round_id": corr.get("round_id"),
                "parent_call_id": corr.get("llm_call_id"),
                "tool_call_id": tool_call_id,
                "tool": fn_name,
                "status": "timeout",
                "timeout_sec": timeout_sec,
                "tool_code": tool_result.code,
                "error_preview": truncate_for_log(sanitize_tool_result_for_log(result), 600),
            },
        )
    except Exception:
        log.debug("Failed to persist tool timeout observability payload", exc_info=True)

    append_jsonl(drive_logs / "events.jsonl", _with_correlation({
        "ts": utc_now_iso(), "type": "tool_timeout",
        "task_id": task_id,
        "tool": fn_name, "args": args_for_log,
        "timeout_sec": timeout_sec,
        "result_ref": trace_ref.get("manifest_ref") if trace_ref else None,
    }, corr, tool_call_id=tool_call_id))
    append_jsonl(drive_logs / "tools.jsonl", _with_correlation({
        "ts": utc_now_iso(), "type": "tool_call", "tool": fn_name,
        "task_id": task_id,
        "args": args_for_log, "result_preview": result,
        "result_ref": trace_ref.get("manifest_ref") if trace_ref else None,
    }, corr, tool_call_id=tool_call_id))

    return {
        "tool_call_id": tool_call_id,
        "fn_name": fn_name,
        "result": result,
        "is_error": True,
        "args_for_log": args_for_log,
        "is_code_tool": is_code_tool,
        "trace_ref": trace_ref, "round_id": corr.get("round_id"),
        "result_meta": result_meta,
        "tool_result": tool_result,
    }


def _execute_with_timeout(
    tools: ToolRegistry,
    tc: Dict[str, Any],
    drive_logs: pathlib.Path,
    timeout_sec: int,
    task_id: str = "",
    stateful_executor: Optional[StatefulToolExecutor] = None,
) -> Dict[str, Any]:
    """Execute one tool call with timeout handling."""
    requested_fn_name = tc["function"]["name"]
    fn_name = str(requested_fn_name or "").strip()
    tool_call_id = tc["id"]
    is_code_tool = fn_name in tools.CODE_TOOLS
    is_reviewed_mutative = fn_name in REVIEWED_MUTATIVE_TOOLS
    use_stateful = stateful_executor and fn_name in STATEFUL_BROWSER_TOOLS
    started_at = time.perf_counter()
    correlation = _tool_correlation(tools)
    tool_ctx = getattr(tools, "_ctx", None)
    args_for_log = sanitize_tool_args_for_log(fn_name, _tc_args(tc))
    # The addressing stamp of the live frames: the routing action this call
    # represents (tool_capabilities owns the family); the chat block renders a
    # stamped call as a receipt row, never as content the block stands on.
    action = routing_action_for_tool(fn_name)
    receipt = {"routing_action": action} if action else {}
    _emit_live_log(tools, _with_correlation({
        "type": "tool_call_started",
        "task_id": task_id,
        "tool": fn_name,
        "timeout_sec": None if is_reviewed_mutative else timeout_sec,
        "terminal_wait": is_reviewed_mutative,
        "args": args_for_log,
        **receipt,
    }, correlation, tool_call_id=tool_call_id))

    if use_stateful:
        assert stateful_executor is not None
        # The generation this call is bound to, captured by the SUBMITTING
        # thread: if the call's own timeout retires it before the worker even
        # reaches the tool body, the wrapper refuses instead of letting the
        # abandoned call build a session in the NEXT command's state.
        submit_generation = getattr(tool_ctx, "browser_state", None)
        with execution_deadline_scope(monotonic_now() + timeout_sec):
            future = stateful_executor.submit(
                _execute_browser_tool_bound, tools, tc, drive_logs, task_id, submit_generation,
            )
        # The registration PINS settlement ownership until this call's own
        # handling is over (result in time, or the late hold claimed below):
        # released in the finally, after either branch (#1196).
        release_tool_custody = budget_pause.register_tool_future(tool_ctx, tool_call_id, fn_name, future)
        try:
            result = future_result(future, timeout_sec)
            result_meta = result.get("result_meta") or {}
            _emit_live_log(tools, _with_correlation({
                "type": "tool_call_finished",
                "task_id": task_id,
                "tool": fn_name,
                **receipt,
                "args": result.get("args_for_log", args_for_log),
                "duration_sec": round(time.perf_counter() - started_at, 3),
                "is_error": bool(result.get("is_error")),
                "status": result_meta.get("status"),
                **_process_fact_fields(result_meta),
                "result_preview": sanitize_tool_result_for_log(
                    truncate_for_log(result.get("result", ""), 500)
                ),
            }, correlation, tool_call_id=tool_call_id))
            return result
        except (TimeoutError, concurrent.futures.TimeoutError):
            settlement_target = future
            on_settled: Optional[Callable[[], None]] = None
            if tool_ctx is not None:  # stateful branch: use_stateful is already true here
                from ouroboros.tools.browser import (
                    _detach_browser,
                    cleanup_browser_handles,
                )

                # CROSS-THREAD INVARIANT (#409): Playwright objects are bound
                # to the worker thread that created them. This main-thread
                # path may only DETACH (retire) the generation — never call
                # close()/stop() here (a cross-thread stop() kills the driver
                # under the hung worker and turns its dispatcher wait into a
                # CPU busy-loop). The close is QUEUED on the retiring
                # executor behind the hung call, so it runs on the owning
                # worker thread whenever that call settles — including the
                # already-settled race, where the queued task runs at once on
                # that same thread (a done-callback would have run HERE, on
                # the main thread, exactly the cross-thread close this path
                # exists to prevent).
                retired_generation, _fresh = _detach_browser(tool_ctx)
                try:
                    settlement_target = stateful_executor.submit(
                        cleanup_browser_handles, retired_generation,
                    )
                except Exception:
                    # Degenerate fallback (executor already dead): settle on
                    # the tool future and close best-effort in its callback.
                    log.debug("cleanup submit failed; falling back to done-callback",
                              exc_info=True)
                    settlement_target = future
                    on_settled = lambda: cleanup_browser_handles(retired_generation)  # noqa: E731
            _attach_late_tool_settlement(
                tools, settlement_target, task_id=task_id, tool_call_id=tool_call_id,
                correlation={**correlation, "tool": fn_name},
                on_settled=on_settled,
            )
            # retire(), not reset(): cancel_futures would cancel exactly the
            # queued cleanup task this path just submitted.
            stateful_executor.retire()
            reset_msg = "Browser state has been reset. "
            timeout_result = _make_timeout_result(
                fn_name, tool_call_id, is_code_tool, tc, drive_logs, timeout_sec, task_id, reset_msg, correlation=correlation)
            _emit_live_log(tools, _with_correlation({
                "type": "tool_call_timeout",
                "task_id": task_id,
                "tool": fn_name,
                "args": args_for_log,
                "duration_sec": round(time.perf_counter() - started_at, 3),
                "timeout_sec": timeout_sec,
            }, correlation, tool_call_id=tool_call_id))
            return timeout_result
        finally:
            release_tool_custody()
    else:
        with abandoned_on_timeout(timeout_sec, bounded=not is_reviewed_mutative) as submit:
            future = submit(_execute_single_tool, tools, tc, drive_logs, task_id)
            # Registered before the wait, so a call abandoned at its timeout is
            # already visible to budget-pause quiescence (#1196); ownership is
            # pinned until the finally below, after any late hold was claimed.
            release_tool_custody = budget_pause.register_tool_future(tool_ctx, tool_call_id, fn_name, future)
            try:
                result = future.result() if is_reviewed_mutative else future_result(future, timeout_sec)
                result_meta = result.get("result_meta") or {}
                _emit_live_log(tools, _with_correlation({
                    "type": "tool_call_finished",
                    "task_id": task_id,
                    "tool": fn_name,
                    **receipt,
                    "args": result.get("args_for_log", args_for_log),
                    "duration_sec": round(time.perf_counter() - started_at, 3),
                    "is_error": bool(result.get("is_error")),
                    "status": result_meta.get("status"),
                    **_process_fact_fields(result_meta),
                    "result_preview": sanitize_tool_result_for_log(
                        truncate_for_log(result.get("result", ""), 500)
                    ),
                }, correlation, tool_call_id=tool_call_id))
                return result
            except (TimeoutError, concurrent.futures.TimeoutError):
                is_foreground_mutative = fn_name in FOREGROUND_MUTATIVE_TOOLS

                if is_foreground_mutative:
                    # Publication-like mutation must not end with an ambiguous timeout.
                    _emit_live_log(tools, _with_correlation({
                        "type": "tool_call_late",
                        "task_id": task_id,
                        "tool": fn_name,
                        "args": args_for_log,
                        "soft_timeout_sec": timeout_sec,
                        "message": (
                            f"Foreground mutative tool '{fn_name}' exceeded "
                            f"{timeout_sec}s — still waiting for result "
                            + "(terminal wait: no background edits)"
                        ),
                    }, correlation, tool_call_id=tool_call_id))
                    # Foreground mutators own effects that cannot safely be
                    # abandoned in a background thread.
                    result = future.result()
                    result_meta = result.get("result_meta") or {}
                    _emit_live_log(tools, _with_correlation({
                        "type": "tool_call_finished",
                        "task_id": task_id,
                        "tool": fn_name,
                        **receipt,
                        "args": result.get("args_for_log", args_for_log),
                        "duration_sec": round(time.perf_counter() - started_at, 3),
                        "is_error": bool(result.get("is_error")),
                        "status": result_meta.get("status"),
                        **_process_fact_fields(result_meta),
                        "late": True,
                        "terminal_wait": True,
                    }, correlation, tool_call_id=tool_call_id))
                    return result
                else:
                    _attach_late_tool_settlement(
                        tools, future, task_id=task_id, tool_call_id=tool_call_id,
                        correlation={**correlation, "tool": fn_name},
                    )
                    timeout_result = _make_timeout_result(
                        fn_name, tool_call_id, is_code_tool, tc, drive_logs, timeout_sec, task_id, correlation=correlation)
                    _emit_live_log(tools, _with_correlation({
                        "type": "tool_call_timeout",
                        "task_id": task_id,
                        "tool": fn_name,
                        "args": args_for_log,
                        "duration_sec": round(time.perf_counter() - started_at, 3),
                        "timeout_sec": timeout_sec,
                    }, correlation, tool_call_id=tool_call_id))
                    return timeout_result
            finally:
                release_tool_custody()


_PARALLEL_SAFE_TOOLS: frozenset[str] = READ_ONLY_PARALLEL_TOOLS | PARALLEL_SAFE_ENQUEUE_TOOLS


def tool_calls_can_run_parallel(tool_calls: List[Dict[str, Any]]) -> bool:
    """True when a tool-call round may execute in the shared ThreadPool.

    Read-only-parallel tools plus fire-and-forget enqueue tools
    (schedule_subagent) qualify; any other tool forces sequential execution.
    """
    return (
        len(tool_calls) > 1
        and all(
            str(tc.get("function", {}).get("name") or "").strip() in _PARALLEL_SAFE_TOOLS
            for tc in tool_calls
        )
    )


def handle_tool_calls(
    tool_calls: List[Dict[str, Any]],
    tools: ToolRegistry,
    drive_logs: pathlib.Path,
    task_id: str,
    stateful_executor: StatefulToolExecutor,
    messages: List[Dict[str, Any]],
    llm_trace: Dict[str, Any],
    emit_progress: Callable[[str], None],
) -> int:
    """Execute tool calls, append results, and return error count."""
    from ouroboros.openai_chat_dispatch import (
        custom_tool_argument_error,
        custom_validation_by_call_id,
    )

    validation = tuple(
        getattr(tools._ctx, "_request_wire_custom_receipts", ()) or ()
    )
    tools._ctx._request_wire_custom_receipts = ()
    validation_by_id = custom_validation_by_call_id(validation)

    def _execute(tc: Dict[str, Any]) -> Dict[str, Any]:
        receipt = validation_by_id.get(str(tc.get("id") or ""))
        if receipt is not None and not receipt.allows_execution:
            fn_name = str((tc.get("function") or {}).get("name") or "").strip()
            result = custom_tool_argument_error(fn_name, receipt)
            return {
                "round_id": getattr(tools._ctx, "_current_llm_call_meta", {}).get("round_id"),
                "tool_call_id": str(tc.get("id") or ""),
                "fn_name": fn_name,
                "result": result,
                "is_error": True,
                "tool_args": {},
                "args_for_log": {},
                "is_code_tool": fn_name in tools.CODE_TOOLS,
                "result_meta": _extract_result_metadata(fn_name, result, True),
            }
        return _execute_with_timeout(
            tools,
            tc,
            drive_logs,
            _get_tool_timeout(
                tools,
                str(tc["function"]["name"] or "").strip(),
                _tc_args(tc),
            ),
            task_id,
            stateful_executor,
        )

    can_parallel = tool_calls_can_run_parallel(tool_calls)

    if not can_parallel:
        results = [_execute(tc) for tc in tool_calls]
    else:
        max_workers = min(len(tool_calls), 8)
        executor = ThreadPoolExecutor(max_workers=max_workers)
        try:
            future_to_index = {
                executor.submit(
                    contextvars.copy_context().run,
                    _execute,
                    tc,
                ): idx
                for idx, tc in enumerate(tool_calls)
            }
            results = [None] * len(tool_calls)
            for future in as_completed(future_to_index):
                idx = future_to_index[future]
                try:
                    results[idx] = future.result()
                except UsageAccountingError:
                    raise
                except Exception as exc:
                    tc = tool_calls[idx]
                    requested_fn_name = tc.get("function", {}).get("name", "unknown")
                    fn_name = str(requested_fn_name or "").strip()
                    safe_error = sanitize_tool_result_for_log(str(exc))
                    result = f"⚠️ TOOL_ERROR: Unexpected error: {safe_error}"
                    tool_result = ToolResult(
                        status="error",
                        code="EXECUTOR_ERROR",
                        text=result,
                    )
                    results[idx] = {
                        "round_id": getattr(tools._ctx, "_current_llm_call_meta", {}).get("round_id"),
                        "tool_call_id": tc.get("id", ""),
                        "fn_name": fn_name,
                        "result": result,
                        "is_error": True,
                        "tool_args": {},
                        "args_for_log": {},
                        "is_code_tool": fn_name in tools.CODE_TOOLS,
                        "result_meta": {
                            **_typed_result_metadata(
                                fn_name,
                                result,
                                True,
                                tool_result,
                            ),
                            **_tool_result_fields(tool_result),
                        },
                        "tool_result": tool_result,
                    }
        finally:
            executor.shutdown(wait=False, cancel_futures=True)

    return process_tool_results(results, messages, llm_trace, emit_progress, tools=tools)


def _maybe_auto_attach_image(
    exec_result: Dict[str, Any],
    tools: Optional[ToolRegistry],
) -> Optional[Dict[str, str]]:
    """Same-round image attachment for tool results that explicitly offer one.

    A successful result whose JSON carries ``auto_attach_image: <local path>`` — a
    typed, opt-in field (the unix_computer_use screenshot emits it) — gets that
    image attached to the conversation immediately, through the SAME
    implementation the ``view_image`` tool uses: identical trust boundary
    (allowed roots, size cap, fail-closed MIME sniff), identical durable copy
    under ``uploads/views``, identical message shape (the mid-round user(image)
    injection the transport already repairs adjacency for). This removes the
    mandatory second ``view_image`` round per observation, which consumed ~21%
    of the round budget on computer-use benches (v6.81.0 OSWorld run: 3,830
    view_image rounds after 3,893 screenshots).

    Parses the FULL result, not the truncated view: per-tool truncation can cut
    the JSON tail. Failure of any kind is strictly non-fatal and must never
    convert a successful tool call into a failed one — the result still carries
    the path, so the agent can view it manually, which is exactly the pre-6.81.1
    behavior.

    EXTENSION tool results only (the ``ext_`` surface): this capability is
    defined for first-party skills, whose payloads the review/grant lifecycle
    already governs. MCP results are untrusted server-supplied data — honoring
    the field there would let a remote server convert an agent-chosen context
    mutation into a data-driven automatic one. (The perimeter below would still
    hold — same roots/size/MIME as view_image — but the narrower surface is the
    honest contract.)"""
    if tools is None or exec_result.get("is_error"):
        return
    if not str(exec_result.get("fn_name") or "").startswith("ext_"):
        return
    # A payload that declares its own failure must not have an image lifted out of
    # it, even when the executor call itself did not raise. Read the typed code the
    # dispatcher published rather than re-deriving the JSON fact here: this guard
    # is the SECOND consumer of that fact and must not drift from the first.
    typed = exec_result.get("tool_result")
    if isinstance(typed, ToolResult) and typed.code == "TOOL_REPORTED_FAILURE":
        return
    raw = (typed.producer_text if isinstance(typed, ToolResult)
           and typed.producer_text is not None else exec_result.get("result"))
    if not isinstance(raw, str) or '"auto_attach_image"' not in raw:
        return
    observation = None
    try:
        parsed = json.loads(raw)
        path = parsed.get("auto_attach_image") if isinstance(parsed, dict) else None
        if not isinstance(path, str) or not path:
            return
        ctx = getattr(tools, "_ctx", None)
        if ctx is None:
            return
        observation = {"status": "unavailable"}
        from ouroboros.tools.vision import attach_local_image_to_context

        ok, note = attach_local_image_to_context(ctx, path)
        observation["status"] = "attached" if ok else "unavailable"
        if not ok:
            log.debug("auto-attach skipped for %s: %s", path, note)
    except Exception:  # noqa: BLE001 - attachment is an enhancement, never a failure
        log.debug("auto-attach image failed", exc_info=True)
    return observation


def reclaim_trace_refs(tool_ctx: Any) -> Dict[str, Any]:
    """Per-task {tool_call_id: trace_ref} accumulated as tool results append."""
    refs = getattr(tool_ctx, "_tool_trace_refs", None)
    return refs if isinstance(refs, dict) else {}


def reclaim_negative_memo(tool_ctx: Any) -> set:
    """Per-task set of non-shrinking reclaim unit keys (created on demand)."""
    memo = getattr(tool_ctx, "_context_reclaim_negative_memo", None)
    if not isinstance(memo, set):
        memo = set()
        tool_ctx._context_reclaim_negative_memo = memo
    return memo


def prune_reclaim_trace_refs(tool_ctx: Any, messages: List[Dict[str, Any]]) -> None:
    """Drop trace refs whose tool_call_id left the transcript (post-reclaim bound)."""
    refs = getattr(tool_ctx, "_tool_trace_refs", None)
    if not isinstance(refs, dict) or not refs:
        return
    live = {
        str(msg.get("tool_call_id"))
        for msg in messages
        if isinstance(msg, dict) and msg.get("tool_call_id")
    }
    for call_id in [key for key in refs if key not in live]:
        del refs[call_id]


def process_tool_results(
    results: List[Dict[str, Any]],
    messages: List[Dict[str, Any]],
    llm_trace: Dict[str, Any],
    emit_progress: Callable[[str], None],
    tools: Optional[ToolRegistry] = None,
) -> int:
    """Append tool results to messages/trace and return error count."""
    error_count = 0

    for exec_result in results:
        fn_name = exec_result["fn_name"]
        is_error = exec_result["is_error"]

        if is_error:
            error_count += 1

        ctx = getattr(tools, "_ctx", None) if tools is not None else None
        from ouroboros.task_pacing import record_tool_activity

        record_tool_activity(ctx, exec_result)
        result_source_ref = (
            _persist_truncated_tool_source(
                ctx, fn_name, str(exec_result["tool_call_id"]), exec_result["result"],
                exec_result.get("tool_args"),
            )
            if ctx is not None else {}
        )
        result_partial = (
            not _should_skip_tool_result_truncation(fn_name, exec_result.get("tool_args"))
            and len(str(exec_result["result"])) > _tool_result_limit(fn_name)
        )
        truncated_result = _truncate_tool_result(
            exec_result["result"],
            tool_name=fn_name,
            tool_args=exec_result.get("tool_args"),
            source_ref=result_source_ref,
        )
        typed = exec_result.get("tool_result")
        producer_ref = {}
        if isinstance(typed, ToolResult) and typed.producer_text is not None:
            if ctx is not None:
                producer_ref = _persist_truncated_tool_source(
                    ctx, fn_name, str(exec_result["tool_call_id"]) + ".producer",
                    typed.producer_text, force=True,
                )
            # The complete annotated source above remains review evidence. This
            # separate source is for parsers; neither bytes nor notes live in meta.
            if result_partial and typed.host_annotations:
                truncated_result += "\n\n" + "\n\n".join(typed.host_annotations)
            truncated_result += (
                "\nPRODUCER_RESULT_SOURCE_JSON=" + json.dumps(producer_ref, ensure_ascii=False)
                + "\nUnannotated tool data for programmatic reading; host notes and outcome still apply."
                if producer_ref else
                "\nPRODUCER_RESULT_SOURCE_UNAVAILABLE=true"
                "\nHost notes remain in the result; no clean producer file was retained."
            )

        messages.append({
            "role": "tool",
            "tool_call_id": exec_result["tool_call_id"],
            "content": truncated_result
        })
        # Keyed on the wake the RESULT published, not on a tool name: a call that published none has nothing to ack.
        if ctx is not None and ((exec_result.get("result_meta") or {}).get("tool_result_meta") or {}).get("supervision_wake_id"):
            try:
                from ouroboros.delegate_supervision import acknowledge_pending_wake

                acknowledge_pending_wake(ctx, truncated_result)
            except Exception:
                log.debug("Failed to acknowledge injected delegate wake", exc_info=True)

        # Retain the pre-truncation trace ref per tool_call_id so the context
        # reclaim materializer can bind exact tool CAS refs into its capsules.
        trace_ref = exec_result.get("trace_ref")
        if ctx is not None and isinstance(trace_ref, dict) and trace_ref:
            refs = getattr(ctx, "_tool_trace_refs", None)
            if not isinstance(refs, dict):
                refs = {}
                ctx._tool_trace_refs = refs
            refs[str(exec_result["tool_call_id"])] = trace_ref

        llm_trace["tool_calls"].append({
            "tool": fn_name,
            "tool_call_id": exec_result["tool_call_id"],
            "args": _safe_args(exec_result["args_for_log"]),
            # Evidence-parity (v6.71.1): store the SAME view the agent saw
            # (per-tool TOOL_RESULT_LIMITS, head-truncated) rather than a hidden
            # 700-char head+tail copy. A decider (acceptance reviewer, reflection)
            # must never adjudicate less of a tool result than the actor did —
            # the old 700 cap cut the middle out and produced false
            # "not shown in trace" verdicts → acceptance loops (BIBLE P1/P3).
            "result": truncated_result,
            "is_error": is_error,
            "trace_ref": exec_result.get("trace_ref"), **({"round_id": exec_result["round_id"]} if exec_result.get("round_id") else {}),
            **({
                "result_partial": True,
                "result_source_ref": result_source_ref,
                "result_source_status": (
                    "ready" if result_source_ref else "source_unavailable"
                ),
            } if result_partial else {}),
            **(exec_result.get("result_meta") or {}),
            **({"producer_source_ref": producer_ref,
                "host_annotations": list(typed.host_annotations)}
               if isinstance(typed, ToolResult) and typed.producer_text is not None else {}),
        })
        if fn_name == "task_acceptance_review" and not is_error:
            raw = str(exec_result.get("result") or "")
            # The auto self-call leads with a compact improvement capsule and wraps
            # the full ReviewRunResult JSON in <full_review>...</full_review> (M5).
            # Extract that block so the FULL record still lands in review_runs even
            # when the visible result is not pure JSON — otherwise an auto review
            # that produced a capsule would record nothing and leave the objective
            # unevaluated exactly when the feedback matters most.
            payload = raw
            if "<full_review>" in raw and "</full_review>" in raw:
                payload = raw.split("<full_review>", 1)[1].rsplit("</full_review>", 1)[0].strip()
            try:
                parsed = json.loads(payload)
                if isinstance(parsed, dict):
                    deferred_to_host = (
                        str(parsed.get("status") or "") == "deferred_to_host_acceptance"
                        and parsed.get("authoritative") is False
                    )
                    if deferred_to_host:
                        llm_trace.setdefault("acceptance_evidence_calls", []).append(parsed)
                        if isinstance(parsed.get("acceptance_retry"), dict):
                            # One explicit, source-bound retry of a disclosed local
                            # preparation failure. Duplicate deliveries are idempotent.
                            from ouroboros.acceptance_preparation import record_retry_intent

                            record_retry_intent(llm_trace, parsed["acceptance_retry"], ctx)
                        if ctx is not None:
                            ctx._acceptance_request_pending = {
                                **(parsed.get("request") or {}),
                                "acceptance_subject": parsed.get("acceptance_subject"),
                            }
                    else:
                        llm_trace.setdefault("review_runs", []).append(parsed)
                    # v6.54.4 (review round 2): dissent is recorded on the agent-called
                    # path too — merge into acceptance_decision without requiring an
                    # agent_decision envelope.
                    if not deferred_to_host and parsed.get("dissent_noted"):
                        _dec = llm_trace.get("acceptance_decision") if isinstance(llm_trace.get("acceptance_decision"), dict) else {}
                        _dec.setdefault("source", "agent_task_acceptance_review_tool")
                        _dec["dissent_noted"] = True
                        llm_trace["acceptance_decision"] = _dec
                    agent_decision = parsed.get("agent_decision") if isinstance(parsed.get("agent_decision"), dict) else {}
                    if agent_decision:
                        from ouroboros.loop_acceptance import merge_agent_acceptance_stance

                        merge_agent_acceptance_stance(llm_trace, agent_decision, ctx)
                        if parsed.get("dissent_noted"):
                            llm_trace["acceptance_decision"]["dissent_noted"] = True
                        # v6.54.4 obligations layer: apply the agent's per-obligation
                        # dispositions onto the host-collected per-task obligations.
                        ob_dispositions = agent_decision.get("obligation_dispositions")
                        if isinstance(ob_dispositions, list) and ob_dispositions:
                            by_id = {
                                str(e.get("id") or ""): e
                                for e in ob_dispositions if isinstance(e, dict)
                            }
                            for ob in (llm_trace.get("acceptance_obligations") or []):
                                if not isinstance(ob, dict):
                                    continue
                                entry = by_id.get(str(ob.get("id") or ""))
                                if entry:
                                    ob["disposition"] = str(entry.get("disposition") or "")
                                    ob["disposition_reason"] = truncate_review_artifact(
                                        str(entry.get("reason") or ""), limit=500,
                                    )
                                    # "agent_disposed", not "disposed": this status renders inside the
                                    # host_attested catalog and must not read as host adjudication
                                    # (host lifecycle values stay "open"/"disposed_by_re_review").
                                    ob["status"] = "agent_disposed"
            except Exception:
                log.debug("Failed to parse task_acceptance_review tool result", exc_info=True)

    # Auto-attach AFTER the round's complete tool-message block, never between two
    # tool messages answering the same assistant turn: the user(image) injection
    # then preserves tool-result contiguity BY CONSTRUCTION instead of relying on
    # the transport's adjacency repair to fix an interleaving we created ourselves.
    by_call = {row["tool_call_id"]: row for row in llm_trace["tool_calls"][-len(results):]}
    for exec_result in results:
        observation = _maybe_auto_attach_image(exec_result, tools)
        if observation:
            by_call[exec_result["tool_call_id"]]["image_attachment"] = observation

    return error_count


def _safe_args(v: Any) -> Any:
    """Ensure args are JSON-serializable for trace logging."""
    try:
        return json.loads(json.dumps(v, ensure_ascii=False, default=str))
    except Exception:
        log.debug("Failed to serialize args for trace logging", exc_info=True)
        return {"_repr": repr(v)}
